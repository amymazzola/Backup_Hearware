HeartWare
=========

This branch contains the HeartWare Android application. 

It uses https://github.com/jjoe64/GraphView library.

