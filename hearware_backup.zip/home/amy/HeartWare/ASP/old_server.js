/*
NODE SETUP
1. make sure server.js and package.json are in the same directory
2. from the same directory run the command 'sudo npm install'. This downloads all the dependencies
for the project that are listed in package.json
3. Make sure you have a MongoDb server up and running by runnning the command 'mongod'
4. Finally run the command 'node server.js' this will spin up a node server on port 8080
where the url is qqroute.com:8x
*/


// call the packages we need
var python_shell = require('python-shell');
var parser = require('body-parser');
var express    = require('express');
var app        = express();
var async 	   = require('async');
var url 	   = require('url');
var request	   = require('request');
console.log("Top");
//Data base connection
var MongoClient = require('mongodb').MongoClient
  , assert = require('assert');

var dbUrl = 'mongodb://localhost:27017/heartware';


/*
=========================================================================
Hardcoded values for api calls
*/
var movement = "https://jawbone.com/nudge/api/v.1.1/users/@me/moves";
//var token = 'Bearer b6_3pfGGwEgExBe8MniV7vFK59dIENPZNLNnPrpoH8wtGScc3zGFLjBV7Kjl0K288EvaJSumcI0GoYT-V9UbpVECdgRlo_GULMgGZS0EumxrKbZFiOmnmAPChBPDZ5JP'

var token = 'Bearer b6_3pfGGwEgExBe8MniV7vFK59dIENPZNLNnPrpoH8wpzi24ZDEk5D9bBZtB4j_l8EvaJSumcI0GoYT-V9UbpVECdgRlo_GULMgGZS0EumxrKbZFiOmnmAPChBPDZ5JP';
var options = {
	url: movement,
	headers : {
	'Accept':'application/json',
	'Authorization': token
	}
}

//============================================================================
/*
RESTful API
==============
1. Authenticate user
2. Pull data from devices
3. write data to mongoDB
=============================
*/
//this is the api you will use in the Android app. The url for it will look the following way.
//http://qqroute.com:8x/getData?username=mazzolaamy@cox.net&password=heartware
//This is a POST request
app.get('/', function(req, res){
 			        python_shell.run('script.py', function(err, results){
		               		 console.log('ran python');
        		       		 console.log( results);
					res.json(results);
  				});
});
app.get('/getData', function(req, res){
	
	//parse request url and grab the query parameters
	var URL = url.parse(req.url, true);
	var query = URL.query;
	/*
	hard coded in for now We'll have to figure out proper auth later on.
	Possibly use Passport, an authentication framework in node that has support
	for OAuth 2.0
	*/
	
	if(query.username == 'mazzolaamy@cox.net' && query.password == 'heartware')
	{

		//RESTful api call for movement
		request(options, function(error, response, body)
		{
			//check to make sure jawbone api call is successful
			if(!error && response.statusCode == 200)
			{

				//function used for inserting data into mongo
				var insertDocuments = function(db, callback) {
				  // Get the documents collection
				  var collection = db.collection('document2');
				  // Insert some documents. JSON.parse(body) contains the jawbone data
				  collection.insert(JSON.parse(body), function(err, result) {
				    assert.equal(err, null);
//				    callback(result);
				  });

				};
				//actually connects to mongodb and calls the insertDocuments function
				MongoClient.connect(dbUrl, function(err, db){
					assert.equal(null, err);

					insertDocuments(db, function(){
						db.close();
					});
				});


 			        python_shell.run('script.py', function(err, results){
		               		 console.log('ran python');
        		       		 console.log( results);
					res.json(results);
  				});

				//send back a success response to the client calling
				
			}
			else
				//jawbone api error. Send error back to client
				res.send(400);
		});
	}

	else
	{
		//Failed Authorization response
		res.send(401, "Incorrect Username or Password");
	}

});

//port app is running on http://qqroute:8x
app.listen(8081);
console.log('server up');
