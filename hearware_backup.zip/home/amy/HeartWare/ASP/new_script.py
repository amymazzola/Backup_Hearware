import subprocess;
subprocess.call("python python_mongo.py", shell=True);
