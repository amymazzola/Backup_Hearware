
import subprocess; 
subprocess.call("clingo asp_capstone.db asp_steps.db asp_capstone", shell=True);
