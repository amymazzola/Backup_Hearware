import json
sampleJson = json.loads('{"one" : "1", "two" : "2", "three" : "3"}')
print sampleJson['two']
