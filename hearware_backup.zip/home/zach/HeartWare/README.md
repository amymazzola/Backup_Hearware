HeartWare
=========

This branch contains the Heartware Android application. Heartware is an application that syncs with a user's Jawbone UP device and provides them with healthy suggestions based on their steps taken each day.

This project is part of Arizona State University's Computer Science capstone curriculum.
